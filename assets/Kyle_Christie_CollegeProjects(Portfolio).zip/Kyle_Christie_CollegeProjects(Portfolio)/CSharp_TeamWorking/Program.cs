﻿//library calls
using System;

namespace CerberusPassTech
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.Title = "PassTech {Dev Build 0.1} - Cerberus Solutions";                            //set console title
            Console.WriteLine("Cerberus Solutions -- PassTech Dev 0.1");                                //print welcome message

            getInput();                                                                                 //call method

            Console.ReadKey();                                                                          //keep console open until any key is pressed
        }

        public static void getInput() 
        {
            int pass_amount, temp_length;                                                               //declare variables

            do {                                                                                        
                Console.WriteLine("Enter password amount");                                             //request password amount from user
                pass_amount = Convert.ToInt32(Console.ReadLine());                                      //get password amount from user
            } while (pass_amount <= 0 || pass_amount > 25);                                             //input validation


            do
            {
                Console.WriteLine("Enter password length");                                             //request password length from user
                temp_length = Convert.ToInt32(Console.ReadLine());                                      //get password length from user
            } while (pass_amount < 8 || pass_amount > 16);                                              //input validation

            Console.WriteLine("Amount: " + pass_amount);                                                //prints values -- solely for dev purposes
            Console.WriteLine("Length: " + temp_length);                                                // ^^see above^^

           
            Console.WriteLine("Generating...");                                                         
            generator(temp_length, pass_amount);                                                        //call method
        
        }


        public static void generator(int temp_length, int pass_amount) 
        {
            P_Generator test = new P_Generator();                                                       //initalise a new password class called test
            test.set_plength(temp_length);                                                              //set class length

            for (int i =0; i < pass_amount; i++)                                                        
            {
                Generate(test);                                                                         //call method
            
            
            }
       
        }


        public static string Generate(P_Generator test) {
  
            test.clear_password();                                                                      //this makes sure passwords don't repeat
            test.set_password();                                                                        //generates a new password

            Console.WriteLine("Your password is: " + test.get_password());                              //prints message and password to user

            return test.get_password();
        }



    }
}
