﻿//library calls
using System;
using System.Threading;    //allows use of sleep() function which provides random num generator to seed properly (ensures passwords don't repeat)                                             
using System.Text;         //holds StringBuilder class

namespace CerberusPassTech
{

    /*
        Cerberus Solutions - PassTech 
        Written: 01/04/2020 
        Client: McLinSoft 
        By: Kyle Christie

        Object-oriented based off of PassWiz and has implementations from Pass++. Class is built so it can be easily implemented into other systems if ever required.

        ~~CHANGE LOG~~
        Kyle - 01/04/2020 - 14:28 - Initital version finished, comment statements added
         
         
     */
   
    public class P_Generator {

        //declare back-end data
        private int length;
        private char[] res_alphabet = { 'A', 'B', 'C', 'D', 'E', 'F', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '!', '"', '£', '$', '%', '^', '&', '*', '(', ')', '-', '_', ':', ';', '@', '#', '~', ',', '.'  };
        private string password;

        //front-end
        public void set_plength(int p_length) { length = p_length; }
        public int get_plength() { return length; }
      
        public void set_password() { password = passwordConstructor(); }
        public string get_password() { return password; }
        public void clear_password() { password = ""; }                 //used to ensure passwords don't repeat



        public string passwordConstructor() 
        {
            Thread.Sleep(30);                                           //pause for 30ms

            var p_builder = new StringBuilder();                        //declare new stringbuilder
            Random ran_num = new Random();                              //declare new random

            int max = res_alphabet.Length;                              //max value for random num, uses .Length for easy dynamic array changes
            int i;                                                
            int char_selector;                                          
            string final_password;

            p_builder.Clear();                                          //ensure passwords don't repeat

            for (i = 0; i < length; i++) {

                char_selector = 0;                                      //set to 0 to ensure chars don't repeat
                char_selector = ran_num.Next(0, max);                   //set selector to a random number from the array
                p_builder.Append(res_alphabet[char_selector]);          //add selected character to the new password string

            }

            final_password = p_builder.ToString();                      //convert to a string so password returns correctly
            return final_password;                                          
            
        }










    };
}
