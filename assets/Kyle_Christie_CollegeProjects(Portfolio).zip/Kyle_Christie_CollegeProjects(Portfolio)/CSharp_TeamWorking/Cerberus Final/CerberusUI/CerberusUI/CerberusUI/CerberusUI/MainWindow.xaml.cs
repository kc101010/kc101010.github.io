﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace CerberusUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            


        }

        public P_Generator User = new P_Generator();

        // ~~~ GENERATE BUTTON INTERACTION ~~~ //
        void GetPasswords_Click(object sender, EventArgs e) 
        {
           
            User.Set_plength((int)LengthSlider.Value);          //set length
            int Amount = (int)NumberSlider.Value;               //set amount (amount doesn't need to declared within the class - instead we call the generator method for the value of method )

            for (int i = 0; i < Amount; i++)
            {
                User.Clear_password();                          //clear previous password - prevent repeats
                User.Set_password();                            //generate password

                Out_Disp.Items.Add(User.Get_password());        //display password to listbox on UI

            }
        }

        // ~~~ CLEAR BUTTON INTERACTION ~~~ //

        void ClearLst_Click(object sender, EventArgs e) { Out_Disp.Items.Clear(); }

        private void NumberSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }


        /* #########################################
         * BROKEN SLIDER CODE: DON'T USE
         * #########################################
        // ~~~ SLIDER INTERACTION ~~~  //
        void NumberSlider_ValueChanged(object sender, RoutedEventArgs e)
        {


            double num = (double)NumberSlider.GetValue(Slider.ValueProperty);
            /*
            Dispatcher.BeginInvoke(new Action(() =>
            {
                this.Content = num.ToString();
            }));

            MessageBox.Show("New Value: " + num.ToString(), "NUMBER SLIDER VALUE");
            //Number_Display.SetCurrentValue(Label.ContentProperty, num.ToString());

        }

        void LengthSlider_ValueChanged(object sender, RoutedEventArgs e)
        {
            double len = (double)LengthSlider.GetValue(Slider.ValueProperty);
            
            Dispatcher.BeginInvoke(new Action(() =>
            {

                this.Content = len.ToString();

            }));

            MessageBox.Show("New Value: " + len.ToString(), "LENGTH SLIDER VALUE");

        }
         */




    }
}

